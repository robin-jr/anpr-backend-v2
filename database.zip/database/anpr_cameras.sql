-- CREATE TABLE `anpr_cameras` (
--   `id` bigint(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
--   `camera_name` varchar(100) NOT NULL,
--   `latitude` decimal(10,7) NOT NULL,
--   `longitude` decimal(10,7) NOT NULL,
--   `rtsp_url` varchar(100) NOT NULL,
--   `http_port` int(11) NOT NULL,
--   `junction_name` varchar(100) NOT NULL,
--   `evidence_camera_name` varchar(100) NOT NULL,
--   `plate_model` varchar(100) NOT NULL,
--   `char_model` varchar(100) NOT NULL,
--   `char_model_width` int(11) NOT NULL,
--   `char_model_height` int(11) NOT NULL,
--   `vid_width` int(11) NOT NULL,
--   `vid_height` int(11) NOT NULL,
--   `char_det_model` varchar(100) NOT NULL,
--   `char_recog_model` varchar(100) NOT NULL,
--   `char_split` tinyint(1) NOT NULL,
--   `plate_threshold` decimal(10,1) NOT NULL,
--   `character_threshold` decimal(10,1) NOT NULL,
--   `plate_interval` int(11) NOT NULL,
--   `roi_y_min` int(11) NOT NULL,
--   `roi_x_min` int(11) NOT NULL,
--   `roi_y_max` int(11) NOT NULL,
--   `roi_x_max` int(11) NOT NULL,
--   `nireq` int(11) NOT NULL,
--   `object_tracking` varchar(100) NOT NULL,
--   `post_processing_method` int(11) NOT NULL,
--   `extras` int(11) NOT NULL,
--   `full_image_save_quality` int(11) NOT NULL,
--   `cropped_image_save_quality` int(11) NOT NULL,
--   `video_display` tinyint(1) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- INSERT INTO `anpr_cameras` (`id`, `camera_name`, `latitude`, `longitude`, `rtsp_url`, `http_port`,`junction_name`,`evidence_camera_name`, `plate_model`, `char_model`, `char_model_width`, `char_model_height`, `vid_width`, `vid_height`, `char_det_model`, `char_recog_model`, `char_split`, `plate_threshold`, `character_threshold`, `plate_interval`, `roi_y_min`, `roi_x_min`, `roi_y_max`, `roi_x_max`, `nireq`, `object_tracking`, `post_processing_method`,  `extras`, `full_image_save_quality`, `cropped_image_save_quality`, `video_display`) VALUES
-- (1, 'Sathya Showroom Front', '13.086990', '80.255017', 'rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov', '9090','Sathya Showroom' ,'Sathya Evidence Camera 1','T31-FP16', 'Default', 304, 192, 1280, 720, 'CD2-FP32', 'CR1', 1, '0.4', '0.2', 1, 0, 0, 720, 1280, 1, 'short-term', 14, -3, 99, 99, 1),
-- (2, 'Sathya Showroom Back', '13.086666', '80.257227', 'rtsp://admin:v1ps%40123@202.61.120.78:5544/Streaming/Channels/101','9091','Sathya Showroom' ,'Sathya Evidence Camera 2','T31-FP16', 'Default', 304, 192, 1280, 720, 'CD2-FP32', 'CR1', 1, '0.4', '0.2', 1, 0, 0, 720, 1280, 1, 'short-term', 14, -3, 99, 99, 1),
-- (3, 'NIFT Entrance', '13.090606', '80.258673', 'rtsp://admin:v1ps%40123@202.61.120.78:5544/Streaming/Channels/101', '9092','Tidal Park Junction' ,'Tidel Park Evidence Camera 1','T31-FP16', 'Default', 304, 192, 1280, 720, 'CD2-FP32', 'CR1', 1, '0.4', '0.2', 1, 0, 0, 720, 1280, 1, 'short-term', 14, -3, 99, 99, 1),
-- (4, 'SRP Tools', '13.107543', '80.265735', 'rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov', '9093','Tidal Park Junction' ,'Tidel Park Evidence Camera 1','T31-FP16', 'Default', 304, 192, 1280, 720, 'CD2-FP32', 'CR1', 1, '0.4', '0.2', 1, 0, 0, 720, 1280, 1, 'short-term', 14, -3, 99, 99, 1),
-- (5, 'NIFT Left', '13.096524', '80.266383', 'rtsp://admin:v1ps%40123@202.61.120.78:5544/Streaming/Channels/101', '9094','Tidal Park Junction' ,'Tidel Park Evidence Camera 2','T31-FP16', 'Default', 304, 192, 1280, 720, 'CD2-FP32', 'CR1', 1, '0.4', '0.2', 1, 0, 0, 720, 1280, 1, 'short-term', 14, -3, 99, 99, 1),
-- (6, 'Sathya Showroom Left', '13.084898','80.266383', 'rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov', '9095', 'Sathya Showroom' ,'Sathya Evidence Camera 1','T31-FP16', 'Default', 304, 192, 1280, 720, 'CD2-FP32', 'CR1', 1, '0.4', '0.2', 1, 0, 0, 720, 1280, 1, 'short-term', 14, -3, 99, 99, 1);


CREATE TABLE `anpr_cameras` (
  `id` int(11) NOT NULL,
  `camera_name` varchar(100) NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `rtsp_url` varchar(400) NOT NULL,
  `http_port` int(11) NOT NULL,
  `junction_name` varchar(400) NOT NULL,
  `evidence_camera_name` varchar(400) NOT NULL,
  `RLVD` tinyint(1) NOT NULL,
  `plate_model` varchar(100) NOT NULL,
  `char_model` varchar(100) NOT NULL,
  `char_model_width` int(11) NOT NULL,
  `char_model_height` int(11) NOT NULL,
  `vid_width` int(11) NOT NULL,
  `vid_height` int(11) NOT NULL,
  `char_det_model` varchar(100) NOT NULL,
  `char_recog_model` varchar(100) NOT NULL,
  `char_split` tinyint(1) NOT NULL,
  `plate_threshold` decimal(10,1) NOT NULL,
  `character_threshold` decimal(10,1) NOT NULL,
  `plate_interval` int(11) NOT NULL,
  `roi_y_min` int(11) NOT NULL,
  `roi_x_min` int(11) NOT NULL,
  `roi_y_max` int(11) NOT NULL,
  `roi_x_max` int(11) NOT NULL,
  `nireq` int(11) NOT NULL,
  `object_tracking` varchar(100) NOT NULL,
  `post_processing_method` int(11) NOT NULL,
  `extras` int(11) NOT NULL,
  `full_image_save_quality` int(11) NOT NULL,
  `cropped_image_save_quality` int(11) NOT NULL,
  `video_display` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anpr_cameras`
--

INSERT INTO `anpr_cameras` (`id`, `camera_name`, `latitude`, `longitude`, `rtsp_url`, `http_port`, `junction_name`, `evidence_camera_name`, `RLVD`, `plate_model`, `char_model`, `char_model_width`, `char_model_height`, `vid_width`, `vid_height`, `char_det_model`, `char_recog_model`, `char_split`, `plate_threshold`, `character_threshold`, `plate_interval`, `roi_y_min`, `roi_x_min`, `roi_y_max`, `roi_x_max`, `nireq`, `object_tracking`, `post_processing_method`, `extras`, `full_image_save_quality`, `cropped_image_save_quality`, `video_display`) VALUES
(1, 'ALCO_169', '13.1037360', '80.2006020', 'rtsp://admin:v1ps%40123@202.61.120.78:5544/Streaming/Channels/101', '9090', 'Junction1', 'EvidenceCamera1', 1, 'T34-208214-FP32', 'Default', 304, 192, 1280, 720, 'CD2-FP32', 'CR1', 0, '0.4', '0.2', 1, 0, 0, 720, 1280, 1, 'short-term', 14, -3, 99, 99, 0),
(2, 'ALCO_170', '13.1037360', '80.2406020', 'rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov','9091', 'Junction2', 'EvidenceCamera1', 1, 'T34-208214-FP32', 'Default', 304, 192, 1280, 720, 'CD2-FP32', 'CR1', 0, '0.4', '0.2', 1, 0, 0, 720, 1280, 1, 'short-term', 14, -3, 99, 99, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anpr_cameras`
--
ALTER TABLE `anpr_cameras`
  ADD PRIMARY KEY (`id`);
